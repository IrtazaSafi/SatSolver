/**
 * Created by irtazasafi on 11/6/16.
 */

enum status {
    UNKNOWN,SATISFIED,CONFLICT,UNSATISFIED,GLOBAL_UNSAT, GLOBAL_SAT
}
