import java.io.IOException;
import java.lang.reflect.Array;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.Stream;




public class SatSolver {


    public  int NUM_VARIABLES;
    public  int NUM_CLAUSES;


    public  int DECISION_LEVEL = 0;

    public  ArrayList<Clause> clauses = new ArrayList<Clause>();
    public  ArrayList<Variable> variables = new ArrayList<Variable>();

    public  ArrayList<Clause> currClauses = new ArrayList<Clause>();
    public  ArrayList<Variable> currVariables = new ArrayList<Variable>();

    public  ArrayList<Variable> decisionVariables = new ArrayList<Variable>();

    public  ArrayList<DecisionLevel> decisionLevels = new ArrayList<DecisionLevel>();

    public  boolean checkExist(Variable _var){
       for(Variable var:variables){
           if(var.var.equals(_var.var)){
               return true;
           }
       }
       return false;
    }

    public  void showVariables(){
        variables.forEach(variable -> System.out.println(variable.var));

    }

    public  void showClauses() {
        clauses.forEach(clause->{
            clause.showLiterals();
            System.out.println();
        });
    }

    public  void showCurrClauses() {
        currClauses.forEach(clause->{
            clause.showLiterals();
            System.out.println();
        });
    }



    public  void extractVariablesAndClauses(String [] clause_in){
        Clause clause = new Clause();
        Arrays.stream(clause_in)
        .filter(var -> !var.equals("0"))
        .forEach((var)->{
            int literal = Integer.parseInt(var);
            int rawVar = Math.abs(literal);

            Variable temp_var = new Variable("x"+String.valueOf(rawVar));
            if(!checkExist(temp_var)){
                variables.add(temp_var);
            }
            clause.addLiteral(new Literal(temp_var,(literal > 0)));
            //System.out.println(literal);

        });
        clauses.add(clause);
    }

    public  void copyOrigIntoCurrent() {
        currClauses.clear();
        currVariables.clear();
        clauses.forEach(clause->{
            currClauses.add(clause.copy());
        });
        variables.forEach(variable -> {
            currVariables.add(variable.copy());
        });
    }

    public  void parse(String FILE_NAME) throws IOException {
        Files.lines(Paths.get(FILE_NAME))
                .map(line-> line.trim().replaceAll(" +", " ").trim())
                .filter(line-> (!line.split(" ")[0].equals("c")) && (!line.split(" ")[0].equals("%")) &&
                        (!line.split(" ")[0].equals("")))
                .forEach((line)->{
                    // PARSE LOGIC HERE

                   // System.out.println(line);

                    String[] parts = line.split(" ");
                    switch (parts[0]) {
                        case "p":
                            NUM_VARIABLES = Integer.parseInt(parts[2]);
                            NUM_CLAUSES = Integer.parseInt(parts[3]);
                            break;
                        default:
                            //System.out.println(parts[0]);
                            extractVariablesAndClauses(parts);
                            break;
                    }


                });
        copyOrigIntoCurrent();
        variables.forEach(variable -> {
            decisionVariables.add(variable.copy());
        });
    }

    public Variable decideNextBranch() {

        decisionVariables.forEach(variable -> {
            // if variable already assigned then no.
        });

        for (Variable var : decisionVariables) {
            if (!var.picked) {
                var.decisionValue = true;
                var.picked = true;
                var.flipped = false;
                return var;
            }
        }

        return null;

    }

    private boolean hasUnitClause(ArrayList<Clause> clauses) {

        for(Clause clause:clauses){
            if(clause.isUnitClause()!=null){
                return true;
            }
        }
        return false;
    }

    private void markPicked(Variable v, boolean decision){
        decisionVariables.stream().filter(decisionVariable -> decisionVariable.var.equals(v.var)).forEach(decisionVariable -> {
            decisionVariable.picked = true;
            decisionVariable.decisionValue = decision;
        });
    }


    private void displayAssignments(ArrayList<Assignment> assignments){
        assignments.forEach(assignment -> {
            System.out.println(assignment.var.var +" " + assignment.phase);
        });
    }

    private status checkStatus(){
       // tell the status

        int unsat = 0;
        int sat = 0;
        int unknown = 0;

        for(Clause clause:currClauses){
            status st = clause.getStatus();
            if(st == status.SATISFIED){
                sat++;
            } else if(st == status.UNKNOWN){
                unknown++;
            } else {
                unsat++;
            }
        }

        if(unknown ==0 && unsat == 0){
            return status.SATISFIED;
        } else if (unknown > 0){
            return status.UNKNOWN;
        } else if(unknown == 0 && unsat > 0){
            return status.CONFLICT;
        }

        return status.UNKNOWN;
    }

    private void bcp(ArrayList<Assignment> assignments){
        while(hasUnitClause(currClauses)){
            currClauses.forEach(clause1 -> {
                Literal lit = clause1.isUnitClause();
                if (lit != null) {
                    // if lit is negative then variable must be assigned false
                    if(!lit.phase){
                        assignments.add(new Assignment(lit.variable,false));
                        markPicked(lit.variable,false);
                        applyAssignments(lit.variable,false);
                    } else {
                        assignments.add(new Assignment(lit.variable,true));
                        markPicked(lit.variable,true);
                        applyAssignments(lit.variable,true);
                    }
                }
            });
        }
    }

    public status  DPLL() {




       return status.GLOBAL_SAT;
    }

    private void applyAssignments(Variable v, boolean assign_phase){
        currClauses.forEach(clause->{
            clause.applyAssignment(v,assign_phase);
        });
    }


    public static void main(String[] args) throws IOException {

        SatSolver solver = new SatSolver();

        solver.parse("simpleTest.cnf");


        solver.showCurrClauses();
        System.out.println("-----------------------");

        solver.applyAssignments(solver.decideNextBranch(),true);

        ArrayList<Assignment> assignments = new ArrayList<Assignment>();

        solver.bcp(assignments);


        solver.showCurrClauses();

      //  System.out.println("-----------------------");




       // System.out.println(solver.checkStatus());

       // System.out.println("-----------------------");

       // solver.displayAssignments(assignments);


    }
}
