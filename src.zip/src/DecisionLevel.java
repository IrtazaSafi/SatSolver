import java.util.ArrayList;

/**
 * Created by irtazasafi on 11/5/16.
 */
public class DecisionLevel {

    ArrayList<Assignment> assignments; // at this level, following variables have been assigned
    int level;
    Variable decisionVariable;

    DecisionLevel(int _level, Variable var){
        decisionVariable = var;
        level = _level;
        assignments = new ArrayList<Assignment>();
    }
    DecisionLevel(int _level, Variable var, ArrayList<Assignment> _in){
        decisionVariable = var;
        level = _level;
        assignments = _in;
    }

    void addAssignment(Variable var, boolean phase){
        assignments.add(new Assignment(var,phase));
    }
}
