/**
 * Created by irtazasafi on 10/28/16.
 */
public class Variable {
    Variable(String _var){
        var = _var;
    }
    String var;
    boolean decisionValue;
    boolean flipped = false;
    boolean picked = false;

    Variable copy(){
        return new Variable(var);
    }


}
