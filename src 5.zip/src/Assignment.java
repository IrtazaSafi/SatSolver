/**
 * Created by irtazasafi on 11/5/16.
 */
public class Assignment {
    Variable var;
    boolean phase;

    Assignment(Variable _var,boolean _phase){
        var = _var;
        phase = _phase;
    }
}
